import { createSelector, createFeatureSelector } from '@ngrx/store';
import { State } from './tuo-reducer';  // sostituisci con il path corretto

export const selectFeature = createFeatureSelector<State>('featureName'); // usa il nome del feature state corretto

export const selectLastBroadcastAction = createSelector(
  selectFeature,
  (state) => state.lastBroadcastAction
);