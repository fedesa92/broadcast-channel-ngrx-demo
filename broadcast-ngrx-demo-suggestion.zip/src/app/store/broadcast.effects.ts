import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, tap } from 'rxjs/operators';
import { BroadcastService } from '../services/broadcast.service';
import * as BroadcastActions from './broadcast.actions';

@Injectable()
export class BroadcastEffects {
  constructor(
    private actions$: Actions,
    private broadcastService: BroadcastService
  ) {}

  send$ = createEffect(() =>
    this.actions$.pipe(
      ofType(BroadcastActions.broadcastSendAction),
      tap(({ actionType, payload }) => {
        this.broadcastService.send({ type: actionType, payload });
      })
    ),
    { dispatch: false }
  );

  receive$ = createEffect(() =>
    this.broadcastService.onMessage().pipe(
      map(({ type, payload }) =>
        BroadcastActions.broadcastReceivedAction({ actionType: type, payload })
      )
    )
  );
}