import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import * as BroadcastActions from '../store/broadcast.actions';
import { Observable } from 'rxjs';
import { selectLastBroadcastAction } from '../store/selectors';

@Component({
  selector: 'app-tab-a',
  template: `
    <h2>Tab A</h2>
    <button (click)="sendUpdate()">Invia Update</button>

    <div *ngIf="lastAction$ | async as lastAction">
      <h4>Azione ricevuta:</h4>
      <pre>{{ lastAction | json }}</pre>
    </div>
  `
})
export class TabAComponent {
  lastAction$: Observable<any>;

  constructor(private store: Store) {
    this.lastAction$ = this.store.select(selectLastBroadcastAction);
  }

  sendUpdate() {
    this.store.dispatch(
      BroadcastActions.broadcastSendAction({
        actionType: 'UPDATE_FROM_TAB_A',
        payload: { message: 'Ciao da Tab A!', timestamp: new Date() }
      })
    );
  }
}