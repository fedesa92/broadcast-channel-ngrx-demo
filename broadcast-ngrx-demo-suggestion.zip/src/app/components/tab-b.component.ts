import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import * as BroadcastActions from '../store/broadcast.actions';
import { Observable } from 'rxjs';
import { selectLastBroadcastAction } from '../store/selectors';

@Component({
  selector: 'app-tab-b',
  template: `
    <h2>Tab B</h2>
    <button (click)="sendUpdate()">Invia Update</button>

    <div *ngIf="lastAction$ | async as lastAction">
      <h4>Azione ricevuta:</h4>
      <pre>{{ lastAction | json }}</pre>
    </div>
  `
})
export class TabBComponent {
  lastAction$: Observable<any>;

  constructor(private store: Store) {
    this.lastAction$ = this.store.select(selectLastBroadcastAction);
  }

  sendUpdate() {
    this.store.dispatch(
      BroadcastActions.broadcastSendAction({
        actionType: 'UPDATE_FROM_TAB_B',
        payload: { message: 'Ciao da Tab B!', timestamp: new Date() }
      })
    );
  }
}