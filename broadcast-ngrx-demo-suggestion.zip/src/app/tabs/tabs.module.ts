import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabAComponent } from '../components/tab-a.component';
import { TabBComponent } from '../components/tab-b.component';
import { TabsRoutingModule } from './tabs-routing.module';

@NgModule({
  declarations: [TabAComponent, TabBComponent],
  imports: [
    CommonModule,
    TabsRoutingModule
  ],
  exports: [TabAComponent, TabBComponent]
})
export class TabsModule {}