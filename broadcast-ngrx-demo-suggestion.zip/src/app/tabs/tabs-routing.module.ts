import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabAComponent } from '../components/tab-a.component';
import { TabBComponent } from '../components/tab-b.component';

const routes: Routes = [
  { path: 'tab-a', component: TabAComponent },
  { path: 'tab-b', component: TabBComponent },
  { path: '', redirectTo: 'tab-a', pathMatch: 'full' },
  { path: '**', redirectTo: 'tab-a' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsRoutingModule {}