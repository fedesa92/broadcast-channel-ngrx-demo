import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-my-grid></app-my-grid>',
})
export class AppComponent {}